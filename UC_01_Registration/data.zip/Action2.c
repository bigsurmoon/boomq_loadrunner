Action2()
{

	lr_start_transaction("UC_01_TR_07_change_password");

	lr_end_transaction("UC_01_TR_07_change_password",LR_AUTO);

	return 0;
}